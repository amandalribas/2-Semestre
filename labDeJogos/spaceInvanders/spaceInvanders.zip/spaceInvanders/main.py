from PPlay.window import *
from PPlay.keyboard import *
import menu


menu.main()