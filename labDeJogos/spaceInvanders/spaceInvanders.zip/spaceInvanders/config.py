linhaEnemy = 3
colunaEnemy = 5
pontos = 0
matrizEnemy = []
dificuldade = 1
vidas = 3
nomes = []
tempos = []
